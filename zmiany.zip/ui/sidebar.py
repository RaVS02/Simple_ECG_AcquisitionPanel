from PyQt6.QtWidgets import QFrame, QVBoxLayout, QLabel, QRadioButton, QButtonGroup
from PyQt6.QtCore import Qt
from resources import config


class Sidebar(QFrame):
    def __init__(self, settingsmanager):
        super().__init__()
        self.setFixedWidth(220)
        self.settingsmanager = settingsmanager
        self.setObjectName("Sidebar")

        # Lista elementów do efektu hover
        self.hover_elements = []

        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 20, 15, 15)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # --- SEKCJA: ŹRÓDŁO SYGNAŁU ---
        self.add_section_title(layout, "ŹRÓDŁO SYGNAŁU")

        self.src_group = QButtonGroup(self)
        self.radio_live = QRadioButton("Na żywo")
        self.radio_live.setChecked(True)
        self.src_group.addButton(self.radio_live)
        layout.addWidget(self.radio_live)

        self.radio_file = QRadioButton("Wczytaj plik")
        self.src_group.addButton(self.radio_file)
        layout.addWidget(self.radio_file)

        self.sep0 = self.add_separator(layout)
        self.hover_elements.append(self.sep0)

        # --- SEKCJA: PARAMETRY DSP ---
        self.add_section_title(layout, "PARAMETRY DSP")

        self.sep1 = self.add_separator(layout)
        self.hover_elements.append(self.sep1)

        # --- SEKCJA: ODPROWADZENIA ---
        self.add_section_title(layout, "ODPROWADZENIA")
        for text in ["I (RA–LA)", "II (RA–LL)", "V1"]:
            rb = QRadioButton(text)
            layout.addWidget(rb)

        self.update_all_styles(active=False)

    def add_section_title(self, layout, text):
        """Dodaje sformatowany tytuł sekcji do układu."""
        lbl = QLabel(text)
        lbl.setStyleSheet(f"""
            color: {config.Colors.DARK_TEXT_SECONDARY}; 
            font-size: 9pt; 
            font-weight: bold; 
            letter-spacing: 1px;
            text-transform: uppercase;
            padding: 0px;
            margin-bottom: 5px;
        """)
        layout.addWidget(lbl)
        return lbl

    def add_separator(self, layout):
        """Tworzy i dodaje separator (linię) do układu."""
        line = QFrame()
        line.setObjectName("SidebarSeparator")
        layout.addWidget(line)
        return line

    def enterEvent(self, event):
        self.update_all_styles(active=True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.update_all_styles(active=False)
        super().leaveEvent(event)

    def update_all_styles(self, active=False):
        """Aktualizuje style wszystkich separatorów na liście."""
        # Pobierz motyw (zakładam, że masz taką metodę w settingsmanager)
        try:
            current_theme = self.settingsmanager.get_theme()
        except AttributeError:
            current_theme = 'light'

        if current_theme == 'dark':
            color = config.Colors.DARK_ACCENT if active else config.Colors.DARK_BORDER
        else:
            color = config.Colors.LIGHT_ACCENT if active else config.Colors.LIGHT_BORDER

        style = f"""
            background-color: {color}; 
            min-height: 1px; 
            max-height: 1px; 
            margin: 5px 0px;
        """

        for element in self.hover_elements:
            element.setStyleSheet(style)