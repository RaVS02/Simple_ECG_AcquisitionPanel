from ui.settings_tab import SettingsTab


class SettingsManager():
    def __init__(self):
        self.current_theme='dark'
    def get_theme(self):
        return self.current_theme
    def set_theme(self, new_theme):
        self.current_theme = new_theme